module.exports = function(app){
  require('./user');
};