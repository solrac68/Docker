# docker-compose-example
Sample app for demonstrating the power of docker-compose
